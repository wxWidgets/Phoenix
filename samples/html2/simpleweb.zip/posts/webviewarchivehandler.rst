.. title: WebViewArchiveHandler
.. slug: webviewarchivehandler
.. date: 2019-10-23 13:05:36 UTC-07:00
.. tags: webview, OtherTag
.. category: 
.. link: 
.. description: 
.. type: text

When this little website is viewed from wxPython's webview sample then all the
resources (html docs, css files, etc.) are being loaded on-demand from a .zip
file.

To accomplish this you just need to add the ``wx.html2.WebViewArchiveHandler`` to
the list of handlers that the WebView uses, and then use a custom link to refer
to the zip file and items within it. 

Here is a copy of the 
`sample script </listings/webview_sample.py.html>`_ for reference.



